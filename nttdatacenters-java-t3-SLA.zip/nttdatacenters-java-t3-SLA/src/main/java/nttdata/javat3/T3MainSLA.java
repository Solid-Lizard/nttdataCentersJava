package nttdata.javat3;

import nttdata.javat3.bussiness.Center;
import nttdata.javat3.bussiness.Employee;
import nttdata.javat3.bussiness.ManagementServiceImpl;
import nttdata.javat3.bussiness.Modality;
import nttdata.javat3.bussiness.Person;
import nttdata.javat3.bussiness.Position;
import nttdata.javat3.bussiness.Project;
import nttdata.javat3.bussiness.Student;

/**
 * Clase - T3MainSLA - Clase principal del proyecto
 * 
 * @author Santiago
 */

public class T3MainSLA {
	
	
	/**
	 * Método - main - Método principal del proyecto
	 * 
	 * @param args
	 */
	public static void main (String[] args) {
		// Creación de objetos y variables //
		ManagementServiceImpl ms = new ManagementServiceImpl();
		
		Person e1 = new Employee();
		Person e2 = new Employee();
		Person e3 = new Employee();
		Person e4 = new Employee();
		
		Person s1 = new Student();
		Person s2 = new Student();
		Person s3 = new Student();
		Person s4 = new Student();
		Person s5 = new Student();
		
		
		// Instrucciones //
		ms.registerPerson(e1, "Hidetaka Miyazaki", "12345678H", null, null, Project.Videogame, Position.PojectLeader);
		ms.registerPerson(e2, "Solid Snake", "99999999S", null, null, Project.Hiring, Position.Junior);
		ms.registerPerson(e3, "Dante", "00000000D", null, null, Project.PhoneApp, Position.Senior);
		ms.registerPerson(e4, "Kratos", "12345678K", null, null,Project.Videogame, Position.Analyst);
		
		ms.registerPerson(s1, "Santi", "88888888S", Center.Salesianas, Modality.DAM, null, null);
		ms.registerPerson(s2, "Alba", "77777777A", Center.Machado, Modality.DAW, null, null);
		ms.registerPerson(s3, "Rafa", "66666666R", Center.Campanillas, Modality.DAW, null, null);	
		ms.registerPerson(s4, "Juanma", "55555555J", Center.Salesianas, Modality.DAM, null, null);
		ms.registerPerson(s5, "Christian", "44444444C", Center.Machado, Modality.DAM, null, null);
		
		ms.launch();
	}
}
