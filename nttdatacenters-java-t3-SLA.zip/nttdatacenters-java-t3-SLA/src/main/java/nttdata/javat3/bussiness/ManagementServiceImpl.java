package nttdata.javat3.bussiness;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

/**
 * Clase - ManagementServiceImpl - Implementa la <b> interfaz ManagementServiceI </b> y añade otra serie de métodos
 * para facilitar la lectura y el manejo de los datos
 * 
 * @author Santiago 
 * @see ManagementServiceI
 */
public class ManagementServiceImpl implements ManagementServiceI{
	// Atributtes //
	public Map<String, Person> BDD = new HashMap<>();	
	Scanner sc = new Scanner(System.in);

	// Check, register and erase instances of Person //
	
	/**
	 * Método - checkPerson - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
	 * esta para leer su funcionamiento
	 * 
	 * @param p1
	 * 
	 * @return boolean
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public boolean checkPerson(Person p1) {
		boolean res = false;
		
		for (Object obj : BDD.keySet()) {
			Person other = BDD.get(obj);
			
			if (p1.equals(other)) {
				res = true;
				break;
			}
			
		}		
		
		return res;
	}
	
	/**
	 * Método - tegisterPerson - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
	 * esta para leer su funcionamiento
	 * 
	 * @param person
	 * @param name
	 * @param dni
	 * @param center
	 * @param modality
	 * @param project
	 * @param position
	 * 
	 * @return boolean
	 * 
	 * @see ManagementServiceI
	 */
	
	@Override
	public boolean registerPerson(Person person, String name, String dni, Center center, Modality modality, Project project, Position position) {
		boolean res = true;
		
		person.setName(name);
		person.setDni(dni.toUpperCase());
		
		if (center == null) {
			Employee emp = (Employee) person;
			emp.setPosition(position);
			emp.setProject(project);
			
			person = emp;		
			
		} else {
			Student st = (Student) person;
			st.setCenter(center);
			st.setModality(modality);
			
			person = st;
		}
		
		if (checkPerson(person)) {
			res = false;
			
		} else {		
			BDD.put(dni, person);
		}
		
		return res;
		
	}
	
	/**
	 * Método - erasePerson - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
	 * esta para leer su funcionamiento
	 * 
	 * @param dni
	 * @return boolean
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public boolean erasePerson(String dni) {
		boolean res = true;
		
		if (BDD.remove(dni)==null) {
			res = false;
		}
		
		return res;
	}

	/**
	 * Método - showPerson - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
	 * esta para leer su funcionamiento
	 * 
	 * @return String
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public String showPersons() {
		String a = "";
		
		for (Object obj : BDD.keySet()) {			
			a+=BDD.get(obj).showDetails();
			a+="\n-------------------------------------\n";			
		}		
		
		return a;
		
	}
	
	/**
	 * Método - searchPerson - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
	 * esta para leer su funcionamiento
	 * 
	 * @param dni
	 * @return Person
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public Person searchPerson(String dni) {		
		return BDD.get(dni);
	}


	/**
	 * Método - showProject - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
	 * esta para leer su funcionamiento
	 * 
	 * @param project
	 * @return String
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public String showProject(Project project) {
		String a = "";
		
		for (Object obj : BDD.keySet()) {
			Person p = BDD.get(obj);
			
			if (p.getType()==Type.Employee) {
				Employee emp = (Employee) p;
				if (emp.getProject()==project) {
					a += emp.toString();
					a+="\n---------------------------------\n";
				}
			}
		}
		
		return a;
	}

	/**
	 * Método - showPosition - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
	 * esta para leer su funcionamiento
	 * 
	 * @param position
	 * @return String
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public String showPosition(Position position) {
		String a = "";
		
		for (Object obj : BDD.keySet()) {
			Person p = BDD.get(obj);
			
			if (p.getType()==Type.Employee) {
				Employee emp = (Employee) p;
				if (emp.getPosition()==position) {
					a += emp.toString();
					a+="\n---------------------------------\n";
					
				}
			}
		}
		
		return a;
	}

	/**
	 * Método - showCenter - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
	 * esta para leer su funcionamiento
	 * 
	 * @param center
	 * @return String
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public String showCenter(Center center) {
		String a = "";
		
		for (Object obj : BDD.keySet()) {
			Person p = BDD.get(obj);
			
			if (p.getType()==Type.Student) {
				Student st = (Student) p;
				if (st.getCenter() == center) {
					a += st.toString();
					a+="\n---------------------------------\n";
					
				}
			}
		}
		
		return a;
	}

	/**
	 * Método - showModality - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
	 * esta para leer su funcionamiento
	 * 
	 * @param modality
	 * @return String
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public String showModality(Modality modality) {
		String a = "";
		
		for (Object obj : BDD.keySet()) {
			Person p = BDD.get(obj);
			
			if (p.getType()==Type.Student) {
				Student st = (Student) p;
				if (st.getModality() == modality) {
					a += st.toString();
					a+="\n---------------------------------\n";
					
				}
			}
		}
		
		return a;
	}

	/**
	 * Método - showCenterAndModality - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
	 * esta para leer su funcionamiento
	 * 
	 * @param center
	 * @param modality
	 * 
	 * @return String
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public String showCenterAndModality(Center center, Modality modality) {
		String a = "";
		
		for (Object obj : BDD.keySet()) {
			Person p = BDD.get(obj);
			
			if (p.getType()==Type.Student) {
				Student st = (Student) p;
				if (st.getModality() == modality && st.getCenter() == center) {
					a += st.toString();
					a+="\n---------------------------------\n";
					
				}
			}
		}
		
		return a;
	}
	
	/**
	 * Método - showProjectAndPosition - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
	 * esta para leer su funcionamiento
	 * 
	 * @param project
	 * @param position
	 * 
	 * @return String
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public String showProjectAndPosition(Project project, Position position) {
		String a = "";
		
		for (Object obj : BDD.keySet()) {
			Person p = BDD.get(obj);
			
			if (p.getType()==Type.Employee) {
				Employee emp = (Employee) p;
				if (emp.getPosition()==position && emp.getProject() == project) {
					a += emp.toString();
					a+="\n---------------------------------\n";
				}
			}
		}
		
		return a;
	}

	/**
	 * Método - showStudent - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
	 * esta para leer su funcionamiento
	 * 
	 * @return String
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public String showStudents() {
		String a = "";
		
		for (Object obj : BDD.keySet()) {
			Person p = BDD.get(obj);
			
			if (p.getType()==Type.Student) {
				a += p.toString();
				a+="\n---------------------------------\n";
				
			}
		}
		
		return a;
	}

	/**
	 * Método - showEmployees - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
	 * esta para leer su funcionamiento
	 * 
	 * @return String
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public String showEmployees() {
		String a = "";
		
		for (Object obj : BDD.keySet()) {
			Person p = BDD.get(obj);
			
			if (p.getType()==Type.Employee) {
				a += p.toString();
				a+="\n---------------------------------\n";
				
			}
		}
		
		return a;
	}

	// "Choose" methods //	
		/**
		 * Método - chooseModality - Método que permite al usuario escoger una modalidad
		 * 
		 * @return Modality - Modalidad escogida por el usuario		 
		 */
		private Modality chooseModality() {
			int option;
			System.out.println("Elige una modalidad");
			System.out.println("1.-DAM");
			System.out.println("2.-DAW");
			option = 0;
			
			while (option != 1 && option != 2) {
				System.out.print("Por favor, introduzca un número del 1 al 2: ");
				option = sc.nextInt();
				
				System.out.println("");
			}
			
			Modality mod;
			
			if (option == 1) {
				mod = Modality.DAM;
				
			} else {
				mod = Modality.DAW;
				
			}
			return mod;
		}

		/**
		 * Método - chooseCenter - Método que permite escoger al usuario un centro
		 * 
		 * @return Center - Centro escogido por el usuario 
		 */
		private Center chooseCenter() {
			int option;
			System.out.println("Elige un colegio");
			System.out.println("1.-Salesianas");
			System.out.println("2.-Machado");
			System.out.println("3.-Campanilla");
			
			option = 0;
			
			while (option>3 || option<1) {
				System.out.print("Porfavor, introduce un número del 1 al 3: ");
				option = sc.nextInt();
				
				System.out.println("");
			}
			
			Center cent;
			
			if (option == 1) {
				cent = Center.Salesianas;
						
			}else if (option==2) {
				cent = Center.Machado;
				
			}else {
				cent = Center.Campanillas;
				
			}
			return cent;
		}

		/**
		 * Método - choosePosition - Método que permite al usuario escoger un puesto de trabajo
		 * 
		 * @return Position - Puestoe scogido por el usuario
		 */
		private Position choosePosition() {
			int option;
			System.out.println("Elija un puesto:");
			System.out.println("1.-Junior");
			System.out.println("2.-Senior");
			System.out.println("3.-Analista");
			System.out.println("4.-Jefe de proyecto");
			option = 0;
			
			while (option<1 || option>4) {
				System.out.println("Introduzca un número del 1 al 4");
				option = sc.nextInt();
			}
			
			Position pos;
			
			if (option == 1) {
				pos = Position.Junior;
				
			} else if (option == 2) {
				pos = Position.Senior;
				
			} else if (option == 3) {
				pos = Position.Analyst;
				
			} else {
				pos = Position.PojectLeader;
				
			}
			return pos;
		}
		
		/**
		 * Método - chooseProject - Permite al usuario escoger un proyecto
		 * 
		 * @return Project - Proyecto escogido por el usuario
		 */
		private Project chooseProject() {
			int option;
			System.out.println("Elija el proyecto");
			System.out.println("1.-Videojuego");
			System.out.println("2.-Contratación");
			System.out.println("3.-App de móvil");
																
			Project pr;
			option = 0;
			
			while (option>3 || option<1) {
				System.out.print("Introduzca un número del 1 al 3: ");
				option = sc.nextInt();
				
				System.out.println("");
			}
			
			if (option==1) {
				pr = Project.Videogame;
				
			} else if (option==2) {
				pr = Project.Hiring;
				
			} else {
				pr = Project.PhoneApp;
				
			}
			return pr;
		}	

	// Launch method //
		/**
		 * Método - launch - Método heredado de la interfaz <b> ManagementServiceI </b> comprobar la documentación de
		 * esta para leer su funcionamiento
		 * 
		 * @see ManagementServiceI
		 */
	@Override
	public void launch() {
		int option = 0;
		
		try {
		
			do {						
				System.out.println("-Bienvenido al sistema de gestión de datos, ¿Qué desea realizar?-");
				System.out.println("1.-Buscar persona");
				System.out.println("2.-Registrar persona");
				System.out.println("3.-Eliminar persona");
				System.out.println("4.-Mostrar personas");
				System.out.println("5.-Salir");
												
				while (option>5 || option <1) {
					System.out.print("Por favor, introduzca un número del 1 al 5: ");
					option = sc.nextInt();
					
					System.out.println("");
				}
				
				System.out.println("----------------------------------------------------------------------");
				
				switch (option) {
				
					case 1:
						System.out.println("Por favor, introduzca el DNI de la persona que busca: ");
						sc.nextLine();
						String dni = sc.nextLine();
						
						Person p = searchPerson(dni.toUpperCase());
						
						if (p == null) {
							System.out.println("Error, no existe ninguna persona que coincida con el parámetro introducido");
							
						} else {
							System.out.println("Persona encontrada, mostrando datos: ");
							System.out.println(p.toString());						
						}
						
						System.out.println("----------------------------------------------------------------------");
						
						option = 0;
						
						break;
												
					case 2:
						Person per = new Employee();
						
						System.out.print("Introduzca un nombre porfavor: ");
						sc.nextLine();
						String name = sc.nextLine();
						
						System.out.println("");											
						
						dni = "";
						
						while(per.checkDni(dni.toUpperCase())==false) {
							System.out.println("Introduce un dni correcto porfavor (8 números y 1 letra)");							
							dni = sc.nextLine();
														
						}
						
						per.setDni(dni.toUpperCase());
						
						if (checkPerson(per)) {
							System.out.println("Error, ya existe una persona con ese DNI");
							
						} else {						
							System.out.println("¿Desea registrar a un empleado o a un estudiante?");
							System.out.println("1.-Empleado");
							System.out.println("2.-Estudiante");
							
							option = 0;
							
							while (option != 1 && option != 2) {
								System.out.print("Por favor, introduzca un número del 1 al 2: ");
								option = sc.nextInt();
								
								System.out.println("");
							}
							
							System.out.println("----------------------------------------------------------------------");
							
							if (option == 2) {
								per = new Student();
								
								Modality mod = chooseModality();
								
								System.out.println("----------------------------------------------------------------------");
															
								Center cent = chooseCenter();
								
								if (registerPerson(per, name, dni, cent, mod, null, null)) {
									System.out.println("Empleado registrado correctamente");
									
								} else {
									System.out.println("Error al introducir el empleado, compruebe que no existe un empleado con el mismo DNI");
								}
								
							} else {
								per = new Employee();
								
								Position pos = choosePosition();
								
								System.out.println("----------------------------------------------------------------------");
								
								Project pr = chooseProject();
								
								registerPerson(per, name, dni.toUpperCase(), null, null, pr, pos);
							}							
														
							System.out.println("Persona creada satisfactoriamente");
							
						}
																	
						System.out.println("----------------------------------------------------------------------");
						
						option = 0;
						
						break;
						
					case 3:
						System.out.println("Introduzca el DNI de la persona que desea eliminar:");
						sc.nextLine();
						dni = sc.nextLine();
						
						if (erasePerson(dni.toUpperCase()) == false) {
							System.out.println("Error, no existe ninguna persona que posea ese DNI");
							
						} else {
							System.out.println("Persona eliminada satisfactoriamente");
						}
						
						System.out.println("----------------------------------------------------------------------");
						
						option = 0;
						
						break;
						
					case 4:
						System.out.println("¿Qué filtros desea aplicar?");
						System.out.println("1.-Mostrar empleados");
						System.out.println("2.-Mostrar alumnos");
						System.out.println("3.-Mostrar alumnos de un colegio");
						System.out.println("4.-Mostrar empleados de un proyecto");
						System.out.println("5.-Mostrar alumnos de un módulo específico");
						System.out.println("6.-Mostrar empleados de una categoría específica");
						System.out.println("7.-Mostrar alumnos de un colegio y un módulo específico");
						System.out.println("8.-Mostrar empleados de un proyecto y una categoría específica");
						System.out.println("9.-Mostrar todos los empleados");
						
						option = 0;
						
						while (option>9 || option<1) {
							System.out.println("Introduzca un número del 1 al 9 porfavor");
							option = sc.nextInt();
							System.out.println();
							
						}
						
						System.out.println("----------------------------------------------------------------------");
						
						switch (option) {
							case 1:
								System.out.println(showEmployees());
								break;
								
							case 2:
								System.out.println(showStudents());
								break;
								
							case 3:																
								Center cent = chooseCenter();
								
								System.out.println(showCenter(cent));														
								break;
								
							case 4:
								Project pr = chooseProject();
								System.out.println(showProject(pr));								
								break;
								
							case 5:
								Modality mod = chooseModality();
								System.out.println(showModality(mod));								
								break;
								
							case 6:
								Position pos = choosePosition();
								System.out.println(showPosition(pos));															
								break;
								
							case 7:
								cent = chooseCenter();
								mod = chooseModality();								
								System.out.println(showCenterAndModality(cent, mod));																
								break;
								
							case 8:
								pr = chooseProject();
								pos = choosePosition();								
								System.out.println(showProjectAndPosition(pr, pos));
								break;
								
							default:
								System.out.println(showPersons());
								break;
						
						}
						
						System.out.println("----------------------------------------------------------------------");
						option = 0;
						break;
						
					default:						
						System.out.println("Cerrando programa....");
						System.out.println("-¡Vuelva pronto!-");						
				}
								
				
			} while (option != 5);
		
		} catch(InputMismatchException ex) {
			System.out.println("Error, porfavor introduzca un parámetro correcto, terminando programa....");
		}
		
	}		
}
