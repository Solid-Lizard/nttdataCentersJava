package nttdata.javat3.bussiness;

/**
 * Interfaz - ManagementServiceI - Prototipo de todos los métodos básicos necesarios para que la implementación
 * de esta interfaz funcione correctamente. La interfaz se encuentra implementada en la clase de <b> ManagementServiceImpl </b>
 * <br>
 * La interfaz se encarga de proporcionar los métodos necesarios para la gestión de personas en la base de datos
 * 
 * @author Santiago
 * @see ManagementServiceImpl
 */

public interface ManagementServiceI {	

	/**
	 * Método - registerPerson - Se encarga de registrar una persona en la base de datos, comprobando previamente si se encuentra ya o no almacenada
	 * 
	 * @param person - Persona que se quiere introducir en la base de datos
	 * @param name - Nombre de la persona
	 * @param dni - DNI de la persona
	 * @param center - Centro en el que estudia la persona (Si es estudiante)
	 * @param modality - Modalidad que estudia la persona (Si es estudiante)
	 * @param project - Proyecto en el que trabaja la persona (Si es empleado)
	 * @param position - Puesto de trabajo de la persona (Si es empleado)
	 * 
	 * @return boolean - true si la persona se añade a la base de datos, false en caso contrario
	 * 
	 * @see Person
	 */
	public boolean registerPerson(Person person, String name, String dni, Center center, Modality modality, Project project, Position position);
	
	/**
	 * Método - checkPerson - Método que comprueba si una persona se encuentra ya registrada en la BDD, para
	 * comprobarlo utiliza el <b> método equals </b> de la <b> clase Person </b>
	 * 
	 * @param p1 - Persona que va a comprobar el método
	 * 
	 * @return boolean - true si la persona se encuentra ya en la BDD, false en caso contrario
	 * 
	 * @see Person
	 */
	public boolean checkPerson(Person p1);
	
	/**
	 * Método - erasePerson - Dado un DNI, elimina a las persona que contenga ese DNI dentro de la BDD
	 * 
	 * @param dni - DNI de la persona que se quiere eliminar
	 * 
	 * @return boolean - true si se consigue eliminar a la persona, false en caso contrario
	 */
	public boolean erasePerson(String dni);
	
	/**
	 * Método - searchPerson - Dado un dni, devuelve a la persona que contenga ese DNI en la BDD
	 * 
	 * @param dni - Dni de la persona que se quiere buscar
	 * 
	 * @return Person - Devuelve un objeto de tipo persona si la encuentra, null en caso contrario
	 * 
	 * @see Person
	 */
	public Person searchPerson(String dni);
	
	/**
	 * Método - showProject - Dado un proyecto, devuelve una cadena con la información de todos los empleados que participan en el
	 * 
	 * @param project - Proyecto solicitado para mostrar a todas las personas que participan en el
	 * 
	 * @return String - Cadena de caracteres con toda la información de los empleados que participan en el proyecto
	 * 
	 * @see Employee
	 */
	public String showProject(Project project);
	
	/**
	 * Método - showPosition - Dado un puesto de trabajo, muestra a todos los empleados que estén en ese puesto
	 * 
	 * @param position - Puesto de trabajo
	 * 
	 * @return String - Cadena de caracteres con la información de los empleados que tienen ese puesto de trabajo
	 * 
	 * @see Employee
	 */
	public String showPosition(Position position);
	
	/**
	 * Método - showCenter - Dado un centro, muestra  a todos los estudiantes que se encuentren en el
	 * 
	 * @param center - Centro
	 * 
	 * @return String - Cadena de caracteres con la información de los empleados que tienen ese puesto de trabajo
	 * 
	 * @see Student
	 */	
	public String showCenter(Center center);
	
	/**
	 * Método - showModality - Dado un módulo, muestra todos los estudiantes que se encuentran cursando ese módulo
	 * 
	 * @param modality - Módulo
	 * 
	 * @return String - Cadena de caracteres con la información de los estudiantes que cursan ese módulo
	 * 
	 * @see Student
	 */
	public String showModality(Modality modality);	
	
	/**
	 * Método - showCenterAndModality - Método que, dados un centro y un módulo, muestra todos los estudiantes que
	 * se encuentran cursando ese módulo y pertenecen a ese centro
	 * 
	 * @param center - Centro de los estudiantes
	 * @param modality - Módulo que cursan los estudiantes
	 * 
	 * @return String - Cadena con toda la información de los estudiantes que coinciden con esos parámetros 
	 * de búsqueda
	 * 
	 * @see Student
	 * 
	 */
		
	public String showCenterAndModality(Center center, Modality modality);
	
	/**
	 * Método - showProjectAndPosition - Método que, dados un royecto y un puesto de trabajo, muestra a todos los
	 * empleados que pertenezcan al proyecto y tengan ese puesto de trabajo
	 * 
	 * @param project - Proyecto al que pertenecen los empleados
	 * @param position - Puesto que tienen los empleados
	 * 
	 * @return String - Cadena con la información de los empleados que coinciden con los parámetros de búsqueda
	 * 
	 * @see Employee
	 */
	public String showProjectAndPosition(Project project, Position position);
	
	/**
	 * Método - showPersons - Método que muestra todas las personas de la BDD
	 * 
	 * @return String - Cadena con la información de todas las personas que pertenecen a la base de datos
	 * 
	 * @see Person
	 */
	public String showPersons();
	
	/**
	 * Método - showStudents - Método que muestra a todos los estudiantes de la BDD
	 * 
	 * @return String - Cadena con la información de todos los estudiantes que pertenecen a la BDD
	 * 
	 * @see Student
	 */
	public String showStudents();
	
	/**
	 * Método - showEmployees - Método que muestra a todos los empleados de la BDD
	 * 
	 * @return String - Cadena con la información de todos los empleados que pertenecen a la BDD
	 * 
	 * @see Employee
	 */
	public String showEmployees();
	
	/**
	 * Método - launch - Método que controla el flujo del programa
	 * 
	 */
	public void launch();
}
