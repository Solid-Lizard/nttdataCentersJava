package nttdata.javat3.bussiness;

/**
 * Enumerado - Type - Indica el tipo de la persona (Empleado o estudiante)
 * 
 * @see Person
 * 
 * @author Santiago
 */
public enum Type {
 Student, Employee
}
