package nttdata.javat3.bussiness;

/**
 * Clase - Employee - Ofrece los atributos y métodos más avanzados para el manejo de empleados, subclase de <b> Person </b>
 * 
 * @see Person
 * @author Santiago
 */

public class Employee extends Person{
	// Attributes //
	private Position position;
	private Project project;
	
	// Constructors //
	/**
	 * Constructor - Employee - Constructor vacío de una instancia de <b> Employee </b>
	 */
	public Employee() {
		setType(Type.Employee);
	}
	
	/**
	 * Constructor - Employee - Constructor 2 de una una instancia de <b> Employee </b>
	 * 
	 * @param name - Nombre del emplead
	 * @param dni - DNI del empleado
	 * @param project - Proyecto asignado al empleado
	 * @param position - Posición asignada al empleado
	 */
	public Employee (String name, String dni, Project project, Position position) {
		super(dni, name);
		this.project = project;
		this.position = position;
		setType(Type.Employee);
	}
		
	// Set & get methods //	
	/**
	 * Método - setPosition - Método que asigna un puesto dado al empleado
	 * 
	 * @param position - Posición del empleado
	 */
	public void setPosition (Position position) {
		this.position = position;
	}	
	
	/**
	 * Método - setProject - Método que asigna un proyecto dado al empleado
	 * 
	 * @param project - Proyecto del empleado
	 */
	public void setProject (Project project) {
		this.project = project;
	}
	
	/**
	 * Método - getPosition - Método que devuelve el puesto al que el empleado está asignado
	 * 
	 * @return Position - Puesto del empleado
	 */
	public Position getPosition() {
		return this.position;
	}
	
	/**
	 * Método - getProject - Método que devuelve el proyecto al que el empleado está asignado
	 * 
	 * @return project - Proyecto del empleado
	 */
	public Project getProject() {
		return this.project;
	}
	
	// Other methods //
	
	/**
	 * Método - toString - Método que devuelve una cadena con la información del empleado, utiliza el método
	 * toString de la <b> clase Person <b> para mostrar parte de la información 
	 * 
	 * @return String - Cdena con la información del empleado
	 * @see Person
	 */
	@Override
	public String toString() {
		return super.toString() + "Posición: " + this.position + "\nProyecto asignado: " + this.project + "\nTipo: Empleado";
	}
	
	/**
	 * Método - showDetails - Método heredado de la clase abstracta <b> Person </b>, leer su documentación para 
	 * comprobar su funcionamiento
	 * 
	 * @return String
	 * @see Person
	 */
	@Override
	public String showDetails() {		
		
		return toString();
				
	}
	

}
