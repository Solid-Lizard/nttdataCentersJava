package nttdata.javat3.bussiness;

/**
 * Enumerado - Center - Enumerado que define el centro al que pertenece una instancia de <b> Student </b>
 * 
 * @see Student
 * @author Santiago
 */

public enum Center {
	Salesianas, Campanillas, Machado
}
