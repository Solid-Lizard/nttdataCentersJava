package nttdata.javat3.bussiness;

/**
 * Enumerado - Center - Enumerado que define el puesto que tiene una instancia de <b> Employee </b>
 * 
 * @see Employee
 * @author Santiago
 */
public enum Position {
	Junior, Senior, Analyst, PojectLeader
}
