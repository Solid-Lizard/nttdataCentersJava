package nttdata.javat3.bussiness;

/**
 * Enumerado - Modality - Enumerado que define la modalidad que cursa un estudiante
 * 
 * @see Student
 * @author Santiago
 */
public enum Modality {
	DAW, DAM
}
