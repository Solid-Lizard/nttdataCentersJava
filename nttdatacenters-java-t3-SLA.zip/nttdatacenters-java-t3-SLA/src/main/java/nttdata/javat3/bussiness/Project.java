package nttdata.javat3.bussiness;

/**
 * Enumerado - Project - Define el proyecto al que el empleado es asignado
 * 
 * @see Employee
 * @author Santiago
 */
public enum Project {
	Videogame, Hiring, PhoneApp
}
