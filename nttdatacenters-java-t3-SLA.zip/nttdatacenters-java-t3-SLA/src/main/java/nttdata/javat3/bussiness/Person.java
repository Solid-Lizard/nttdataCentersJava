package nttdata.javat3.bussiness;
/**
 * Clase abstracta - Person - Clase que ofrece los atributos y métodos básicos para manejar a cualquier
 * instancia de <b> Person </b>, super clase de <b> Employee </b> y <b> Sudent </b>
 * 
 * @see Student
 * @see Emplyee
 * @author Santiago
 */
public abstract class Person {
	// Attributes //
	private String dni, name;
	private Type type;
	
	// Constructors //
	/**
	 * Constructor - Person - Constructor vacío de una instancia de <b> Person </b>
	 */
	public Person () {}
	
	/**
	 * Constructor - Person - Constructor completo de una instancia de <b> Person </b>
	 * 
	 * @param dni - DNI de la persona
	 * @param name - Nombre de la persona
	 */
	public Person (String dni, String name) {
		this.dni = dni;
		this.name = name;
		
	}		
	
	// Set and Get methods //
	
	/**
	 * Método - setName - Método que, dado un nombre lo asigna a una Persona
	 * 
	 * @param name - Nombre de la persona
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Método - setType - Método que, dado un tipo lo asigna a una Persona
	 * 
	 * @param type - Nombre de la persona
	 */
	public void setType(Type type) {
		this.type = type;
	}
	
	/**
	 * Método - setDni - Método que, dado un DNI lo asigna a una Persona
	 * 
	 * @param dni - Dni de la persona
	 * 
	 * @return boolean - true si el DNI se asigna, false en caso contrario
	 */
	public boolean setDni(String dni) {
		boolean res = false;
		
			if(checkDni(dni)) {
				this.dni=dni;
				res = true;
			}
		
		return res;
	}
	
	/**
	 * Método - getName - Método que devuelve el nombre de una persona
	 * 
	 * @return String - Nombre de la persona
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Método - getDni - Método que devuelve el DNI de una persona
	 * 
	 * @return String - Dni de la persona
	 */
	public String getDni() {
		return this.dni;
	}
	
	/**
	 * Método - getDni - Método que devuelve el tipo (Estudiante o empleado) de una persona
	 * 
	 * @return Type - Tipo de la persona
	 */
	public Type getType () {
		return this.type;
	}
	
	// Other methods //	
	/**
	 * Método - endsWithLetter - Método que comprueba si una cadena termina en una letra
	 * 
	 * @param str - Cadena que va a ser evaluada
	 * 
	 * @return boolean - true si la cadena termina en una letra, false en caso contrario
	 */
	protected boolean endsWithLetter (String str) {

		boolean result = false;		
		char[] alphabet = new char[26];
		
		for (int i = 0; i<26; i++) {			 
			 int ascii = 65 + i;
			 
			 alphabet[i] = (char) ascii;
			 			 		
		 }		
		
		for (char letter : alphabet) {
			if (str.endsWith(Character.toString(letter))) {
				result = true;
				break;
			}
			
		}
				
		return result;					
	}
	
	/**
	 * Método - checkDni - Método que comprueba si un DNI es válido
	 * 
	 * @param dni - DNI que va a ser evaluado
	 * 
	 * @return boolean - true si el DNI es válido, false en caso contrario
	 */
	protected boolean checkDni(String dni) {
		boolean res = false;				
		
			if (dni.length()==9 && endsWithLetter(dni)) {
				res = true;
			}
		
		return res;
	}		
	
	/**
	 * Método - toString - Método que devuelve una cadena con la información de la persona
	 * 
	 * @return String - Cadena con la información de la persona
	 */
	@Override
	public String toString() {
		return "Nombre: " + name + "\n" + "DNI: " + dni + "\n";
		
	}
	
	/**
	 * Método - equals - Método que comprueba si dos instancias de <b> Persona </b> son iguales,
	 * comparando sus DNI
	 * 
	 * @param obj - Otra persona con la que vamos a comparar una instancia de <b> Persona </b>
	 * 
	 * @return boolean - true si ambos DNI son iguales, false en caso contrario
	 */
	@Override
	public boolean equals(Object obj) {
		boolean res = false;
		
		Person other = (Person) obj;
		
		if (other.dni.equals(this.dni)) {
			res = true;
		}
		
		return res;
	}
	
	/**
	 * Método - showDetails - Método que devuelve toda la información de una persona.
	 * 	 
	 * @return String - Cadena con la información de una persona.
	 */
	public abstract String showDetails();
}
