package nttdata.javat3.bussiness;

/**
 * Clase - Student - Ofrece los atributos y métodos más avanzados para el manejo de estudiantes, subclase de <b> Person </b>
 * 
 * @see Person
 * @author Santiago
 */
public class Student extends Person{
	// Attributes //
	private Center center;
	private Modality modality;
	
	
	// Constructors //
	
	/**
	 * Constructor - Student - Constructor vacío de una instancia de <b> Student </b>	
	 */	
	public Student() {
		setType(Type.Student);
	}
	
	/**
	 * Constructor - Student - Constructor 2 de una instancia de <b> Student </b>, utiliza el constructor de la
	 * clase <b> Person </b> para construir sus atributos	
	 * 
	 * @param dni - DNI del estudiante
	 * @param name - Nombre del estudiante
	 * @param center - Centro al que pertenece el estudiante
	 * @param modality - Módulo que cursa el estudiante
	 * 
	 * @see Person
	 */
	public Student(String dni, String name, Center center, Modality modality) {
		super (dni, name);
		this.center = center;
		this.modality = modality;
		setType(Type.Student);
	}
	
	// Set & Get methods //
	
	/**
	 * Método - setCenter - Método que asigna un centro al estudiante
	 * 
	 * @param center - Centro que se va a asignar
	 */
	public void setCenter (Center center) {
		this.center = center;
	}
	
	/**
	 * Método - setModality - Método que asigna un módulo al estudiante
	 * 
	 * @param modality - Módulo que se va a asignar
	 */
	public void setModality(Modality modality) {
		this.modality = modality;
	}
	
	/**
	 * Método - getCenter - Método que devuelve el centro al que pertenece el estudiante
	 * 
	 * @return Center - Centro al que pertenece el estudiante
	 */
	public Center getCenter() {
		return this.center;
	}
	
	/**
	 * Método - gerModality - Método que devuelve el módulo que cursa el estudiante
	 * 
	 * @return Modality - Módulo que cursa el estudiante
	 */	
	public Modality getModality() {
		return this.modality;
	}
	
	/**
	 * Método - toString - Método que devuelve una cadena con la información del estudiante, utiliza el 
	 * método toString de su clase padre 
	 * 
	 * @return String - Información del estudiante
	 * 
	 * @see Person
	 */
	@Override
	public String toString() {
		String res = super.toString() + "Centro: " +  this.center +"\n" + "Modalidad: " + this.modality + "\nTipo: estudiante";
		
		return res;
	}
	
	// Other methods //
	/**
	 * Método - showDetails - Método heredado de la clase abstracta <b> Person </b>, leer su documentación para 
	 * comprobar su funcionamiento
	 * 
	 * @return String
	 */
	@Override
	public String showDetails() {
		return this.toString();
	}

}
