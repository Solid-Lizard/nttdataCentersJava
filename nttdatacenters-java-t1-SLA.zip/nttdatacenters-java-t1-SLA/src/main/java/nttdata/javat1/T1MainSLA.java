package nttdata.javat1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nttdata.javat1.game.Game;

/**
 * <h2> Class T1MainSLA - Main class of the project </h2>
 * It will execute the <b>launchAndStart</b> method of a <b>Game</b> instance
 * @see Game
 * @version 1.2
 * @author Santiago López Arredondo
 * @since 16-05-2022
 */

public class T1MainSLA {
	
	/**
	 * @param args
	 */
	
	public static void main (String[] args) {		
		final Logger log = LoggerFactory.getLogger(T1MainSLA.class);
		final Game g1 = new Game();
		
		log.info("INICIO DE PROGRAMA");
		
		g1.launchAndStart();
		
		log.info("FIN DE PROGRAMA");
					
	}	
}
