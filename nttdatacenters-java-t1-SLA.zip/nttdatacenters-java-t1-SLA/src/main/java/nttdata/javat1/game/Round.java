package nttdata.javat1.game;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <h2> Class Round - Controls the events of one round of the game </h2>
 *   
 * @version 1.0
 * @author Santiago López Arredondo
 * @since 16-05-2022
 * @see Game
 * @see Ball
 */

public class Round {
	
	Logger log = LoggerFactory.getLogger(Round.class);
	
	// Attributes //
	private int score = 0;
	private Ball b1 = new Ball();	

	// Methods //
	
	/**
	 * This method counts the score of the player (depending of the status of the ball) and the bounces of the ball
	 * @see Player
	 * @see Ball
	 */	
	
	public void countScore() {
		if (b1.getStatus() == Status.STANDARD) {
			score+=100;
			b1.rebound();
			
		} else if (b1.getStatus() == Status.BONUS) {
			score+=500;
			b1.rebound();
			
		} else if (b1.getStatus() == Status.NOPOINTS) {
			b1.rebound();
		}	
		
		log.info("PUNTOS Y BOTES ACTUALIZADOS, PUNTOS: [" + score + "] REBOTES: [" + b1.getRebounds() + "]");
		
	}
	
	/**
	 * This method controls the flow and the succession of events of one round of the game. The evens occur 
	 * within a probability and the round finishes when the ball gains the "OUT" status
	 * @see Ball
	 * @see Player
	 * @see ScoreTable
	 */	
	
	public void beginRound(Player p1) {	
		log.info("INICIO DE LA RONDA");
		
		System.out.println("-------------------------EMPIEZA EL JUEGO-------------------------");
		
		do {
			generateEvent(p1);
			
			countScore();
			
		} while (b1.getStatus() != Status.OUT);
				
		b1.newRound();				
	}

	/**
	 * This method generates an event and changes the status of the ball depending of the number
	 * @param p1 - The player that will suffer an event
	 */
	
	private void generateEvent(Player p1) {
		int event = (int) (Math.random() * 100) + 1;		
		
		if (event<=50) {
			b1.standard();						
			System.out.println("--Golpeas la bola y rebota + 100 puntos");
			
		} else if (event <= 90) {
			b1.bonus();
			System.out.println("--¡Golpeas la bola y rebota varias veces! + 500 puntos");
			
		} else if (event <= 98) {
			b1.noPoint();
			System.out.println("--Golpeas la bola pero no ganas puntuación");
			
		} else {
			endRound(p1);
		}
	}

	/**
	 * This method will end a round, changing the status of the ball to "OUT", and showing the data of the round, and updating the player maxScore if necessary 
	 * @param p1 - The player that will be updated
	 */
	
	private void endRound(Player p1) {
		b1.out();
		
		log.info("FIN DE RONDA, PUNTUACION: {}", score);
		
		System.out.println("¡La bola ha entrado, fin de la partida!");				
		System.out.println("Su puntuación es: " + score);
		System.out.println("Su número de rebotes ha sido: " + b1.getRebounds());
		System.out.println("");
		
		if (p1.updateMaxScore(score)) {
			System.out.println("¡Felicidades!, has hecho un NUEVO RECORD");
		}
		
		System.out.println("");
		
		if (score<1) {
			System.out.println("- P-pero ¡¿Se puede saber que has hecho para tener CERO puntos?!");
			
		} else if (score<100) {
			System.out.println("-Un bebé lo haría mejor");
			
		} else if (score <500) {
			System.out.println("-Al menos lo has intentado...");
			
		} else if (score <1000) {
			System.out.println("-Mejora un poco y no darás asco");
			
		} else if (score <5000) {
			System.out.println("-¡Felicidades! eres muy malo jugando a este juego");
			
		} else if (score < 10000) {
			System.out.println("-No te vengas arriba, seguro que es la suerte del principiante");
			
		} else {
			System.out.println("-No esperes una carta de felicitacion que es solo un juego");
		}
	}	
	
}
