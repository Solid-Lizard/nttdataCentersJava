package nttdata.javat1.game;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <h2> Class Game - An instance of <b>Game</b> is used to control the flow of the program's course </h2>  
 * @version 1.0
 * @author Santiago López Arredondo
 * @since 16-05-2022
 */

public class Game {	
	
	private final Logger log = LoggerFactory.getLogger(Game.class);	
	
	/**
	 * Method that checks if the value for "option" is invalid
	 * @return boolean - true if the option is valid, false if not. 
	 */
	
	private boolean checkOption(int option) {		
		boolean resultado = true;
		
		if (option <1 || option>4) {
			resultado = false;
			
			log.error("VALOR PARA OPTION INCORRECTO: {}", option);
		}			 
			 		 
		return resultado;
	}
	
	/**
	 * This method launches the game, creating the needed instances of <b> Player </b>
	 * and <b> ScoreTable </b>, this method calls all of the methods needed to start rounds,
	 * save the best scores of the player, show the table of the bests Scores, exit the game....
	 * 
	 * @see Player
	 * @see ScoreTable
	 * @see Round
	 */		
	
	public void launchAndStart() {		
		
		log.info("INICIANDO MÉTODO");
		
		// Objects, variables and tables //
		Scanner sc = new Scanner(System.in);
		
		Player j1 = new Player("Santiago", 1000000);
		Player j2 = new Player("Samus", 20000);
		Player j3 = new Player("Batman", 18500);
		Player j4 = new Player("Snake", 15300);
		Player j5 = new Player("Dante", 14000);
				
		
		ScoreTable table = new ScoreTable();
		
		// Instructions //		
		table.insertPlayer(j1);
		table.insertPlayer(j3);
		table.insertPlayer(j2);
		table.insertPlayer(j5);
		table.insertPlayer(j4);
		
		log.info("JUGADORES Y TABLA CREADOS SATISFACTORIAMENTE");
		
		System.out.println("---------------------------------------Bienvenido THE PINBALL 90000X---------------------------------------");
		System.out.print("Antes de empezar, necesitamos que introduzca su nombre porfavor (Máximo 8 caracteres): ");				
		
		Player p1 = new Player ();		
		String name = sc.nextLine();
		
		while (!(p1.setName(name))) {			
			System.out.println("Error, has introducido un nombre no válido,");
			System.out.print("vuelva a introducir un nombre por favor: ");			
			name = sc.nextLine();		
		}
			
		
		log.info("VALOR INTRODUCIDO DE NOMBRE: {}", name);							
		log.info("JUGADOR CREADO SATISFACTORIAMENTE");
									
		try {
			int option;
			 			 
			 do {	
				 log.info("INICIO DEL BUCLE");
				 
			 	System.out.println("-------------------------------------------------");
				System.out.println("-Por favor, escoja una de las siguientes opciones");
				System.out.println("1.-Iniciar partida");
				System.out.println("2.-Ver información de jugador");
				System.out.println("3.-Ver tabla de mejores puntuaciones");
				System.out.println("4.-Salir");
				System.out.println("-------------------------------------------------");
				System.out.print("Su opción: ");												
				 
				option = sc.nextInt();
				
				while (!(checkOption(option))) {
					System.out.println("Error, el dato introducido debe encontrarse entre 1 y 4");
					option = sc.nextInt();
				}
				 
				log.info("VALOR INTRODUCIDO PARA OPCIÓN: {}", option);
				 
				System.out.println("-------------------------------------------------");
				 
				switch (option) {
			 		case 1:
				 		System.out.println("¡Buena suerte!");
				 		
				 		Round r1 = new Round();	
				 		
				 		r1.beginRound(p1);				 		
				 		table.replacePlayer(p1);
				 		
				 		break;
				 		
				 	case 2:				 		
				 		System.out.println(p1);
				 		break;
				 		
				 	case 3:
				 		table.showTable();
				 		break;
				 		
				 	case 4:
				 		System.out.println("---¡Vuelve pronto!---");
				 		break;
				 }				 				
				 
			 } while (option != 4);			 			
			
		} catch (InputMismatchException ex) {
			log.error("ERROR AL INTRODUCIR UN VALOR NO ACEPTADO, MENSAJE DE ERROR: {}", ex);
			System.out.println("--Error, usted no ha introducido un número entero, porfavor, ejecute de nuevo el programa");						
			
		}
	
		sc.close();				
		
	}	
}
