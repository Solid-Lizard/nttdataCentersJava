package nttdata.javat1.game;

/**
 * <h2> Enumeration Status - Controls the status of the ball, which defines how many points for bounce the 
 * player scores, if the ball has the Status "OUT", the round finishes</h2>
 *   
 * @version 1.0
 * @author Santiago López Arredondo
 * @since 16-05-2022 
 * @see Ball
 */

public enum Status {
	START, NOPOINTS, STANDARD, BONUS, OUT
}
