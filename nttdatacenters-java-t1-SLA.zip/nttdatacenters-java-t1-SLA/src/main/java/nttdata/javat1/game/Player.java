package nttdata.javat1.game;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <h2> Enumeration Rank - The player gets a Rank depending on the maxScore he gets</h2>
 *   
 * @version 1.0
 * @author Santiago López Arredondo
 * @since 16-05-2022 
 * @see Player
 */
enum Rank {
	NOOB, PADAWAN, KNIGHT, MASTER
}

/**
 * <h2> Class Player - The class player contains the data and methods needed for storing the Player's name and 
 * it's best Score on a Single Round, this is used to classify the scores in ScoreTable </h2>
 *   
 * @version 1.0
 * @author Santiago López Arredondo
 * @since 16-05-2022
 * @see ScoreTable
 * @see Rank
 */

public class Player implements Comparable<Object>{
	private final Logger log = LoggerFactory.getLogger(Player.class);
	
	// Attributes //
	private String name;
	private int maxScore = 0;	
	private Rank rank = Rank.NOOB;
	
	// Builders //	
	
	/**
	 * Empty builder of an instance of <b> Player </b>
	 */
	
	public Player() {
		
	}
	
	/**
	 * Builder 1 of a <b> Player </b> instance
	 * @param name - Name of the player
	 */
	
	public Player(String name) {		
		this.name = name;
		log.info("CREADO EL JUGADOR: {}", this.name);
		updateMaxScore(this.maxScore);								
		
	}	
	
	/**
	 * Builder 2 of a <b> Player </b> instance
	 * @param name - Name of the player
	 * @param maxScore - Max score of the player
	 */
	public Player(String name, int maxScore) {
		this.name = name;
		log.info("CREADO EL JUGADOR: {}", this.name);
		updateMaxScore(maxScore);
	}
	
	// Other methods //
	
	/**
	 * This method updates the rank of the player using it's maxScore
	 */
	
	public void updateRank() {
		if (maxScore<=1000) {
			this.rank = Rank.NOOB;
			
		} else if (maxScore<=5000) {
			this.rank = Rank.PADAWAN;
			
		} else if (maxScore<=10000) {
			this.rank = Rank.KNIGHT;
			
		} else {
			this.rank = Rank.MASTER;
		}
		
		log.info("RANGO DE JUGADOR ACTUALIZADO A: {}", this.rank);
		
	}
	
	
	/**
	 * This method updates the maxScore if the roundScore is bigger than the current maxScore
	 * @param roundScore - int - The integer that will be compared to maxScore
	 * @return true or false depending if the maxScore was updated or not
	 */
	public boolean updateMaxScore (int roundScore) {				
		boolean result = false;
		
		if (roundScore>maxScore) {
			maxScore = roundScore;
			
			result = true;
		}
		
		updateRank();
		
		log.info("FIN DEL MÉTODO, VALOR DEVUELTO: {}", result);
		
		return result;
	}		
	
	/**
	 * Overrides the toString method of the object class.
	 * @return A string with the player info
	 */
	
	@Override
	public String toString () {
		String info = "Nombre del jugador: " + name + "\nPuntuación máxima: " + maxScore + "\nRango: " + rank;
		
		log.info("INFORMACIÓN MOSTRADA DEL JUGADOR: {}", name);
		
		return info;		
	}	
	
	/**
	 * This method returns the name of the player
	 * @return String - name of the player
	 */
	
	public String getName() {
		return this.name;
	}
	
	/**
	 * This method returns the max score of the player
	 * @return int - the maxScore of the player
	 */
	
	public int getMaxScore() {
		return this.maxScore;
	}
	
	/**
	 * This method returns the rank of the player
	 * @return Rank - rank of the player
	 */
	
	public Rank getRank() {
		return this.rank;
	}
	
	
	/**
	 * Overrides the compareTo method of the Comparable interface, this helps to order the players in the instance of
	 * ScoreTable
	 * @param obj - The object to be compared with, it will be cast to "Player" before the comparative
	 * @return 1 or -1 depending if the maxScore of the compared Player is bigger or smaller than the maxScor of another Player
	 * @see ScoreTable
	 */
	
	@Override
	public int compareTo(Object obj) {			
		Player other = (Player) obj;
		
		log.info("INICIO DEL MÉTODO, JUGADORES A COMPARAR: " + this.name + " Y " + other.name);
		
		int result;
		
		if (other.maxScore>this.maxScore) {
			result = 1;
		} else {
			result = -1;
		}
		
		log.info("MÉTODO FINALIZADO, VALOR DEVUELTO: {}", result);
		
		return result;
	}		
	
	/**
	 * Overrides the <b> equals </b> method of the <b> Object </b> class
	 * @param obj - The object to be compared with, it will be casted to "Player" before the comparative
	 * @return true or false depending if the objects have the same name and maxScore
	 */
	@Override
	public boolean equals(Object obj) {
		boolean equals = false;
		
		Player other = (Player) obj;
		
		log.info("INICIO DEL MÉTODO, JUGADORES A COMPARAR: " + this.name + " Y " + other.name);
		
		if (this.name==other.name && this.maxScore==other.maxScore) {
			equals = true;
		}
		
		log.info("FIN DEL MÉTODO, VALOR DEVUELTO: {}", equals);
		
		return equals;		
	}
	
	/**
	 * This method sets the name of the player
	 * @return boolean - true if the name is set, false if not
	 */
	
	public boolean setName(String name) {
		boolean resultado = true;
		
		if (name.length()<1 || name.length()>8) {
			resultado = false;
			log.error("EL JUGADOR HA INTRODUCIDO UN VALOR INCORRECTO COMO NOMBRE: {}", name);
			
		} else {
			this.name = name;
		}
		
		return resultado;
	}
	
}
