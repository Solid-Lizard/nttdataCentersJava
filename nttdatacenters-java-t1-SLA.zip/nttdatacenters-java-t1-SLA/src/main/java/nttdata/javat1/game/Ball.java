package nttdata.javat1.game;

/**
 * <h2> Class Ball - This class contains the methods used to control the flow of the ball during a round</h2>  
 * @version 1.1
 * @author Santiago López Arredondo
 * @since 16-05-2022 
 * @see Status
 */

public class Ball {
	// Attributes //
	Status status = Status.START;
	int rebounds = 0;
	
	// Methods //
		
	/**
	 * This method registers one bounce
	 */
	public void rebound() {
		rebounds++;
	}
	
	/**
	 * This method is used when a round starts, it sets the ball properties
	 * to its initial properties
	 */
	public void newRound() {
		status = Status.STANDARD; 
		rebounds = 0;
	}
	
	/**
	 * All of this methods change the status of the ball, depending on its status
	 * the player will score more or less points
	 * @see Round
	 */
	
	public void bonus() {
		status = Status.BONUS; 	
	}
	
	public void noPoint() {
		status = Status.NOPOINTS; 
	}
	
	public void standard() {
		status = Status.STANDARD;
	}
	
	public void out() {
		status = Status.OUT; 
	}
	
}
