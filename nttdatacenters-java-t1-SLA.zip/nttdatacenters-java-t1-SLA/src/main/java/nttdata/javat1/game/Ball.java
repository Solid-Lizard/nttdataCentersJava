package nttdata.javat1.game;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <h2> Class Ball - This class contains the methods used to control the flow of the ball during a round</h2>  
 * @version 1.1
 * @author Santiago López Arredondo
 * @since 16-05-2022 
 * @see Status
 */

public class Ball {
	
	Logger log = LoggerFactory.getLogger(Ball.class);
	
	// Attributes //
	Status status = Status.START;
	int rebounds = 0;
	
	// Methods //
		
	/**
	 * This method registers one bounce
	 */
	public void rebound() {
		rebounds++;
		log.info("NÚMERO DE BOTES AUMENTADO A: {}", rebounds);
	}
	
	/**
	 * This method is used when a round starts, it sets the ball properties
	 * to its initial properties
	 */
	public void newRound() {
		status = Status.STANDARD; 
		rebounds = 0;
		
		log.info("MÉTEDO EJECUTADO CORRECTAMENTE");
	}
	
	/**
	 * All of this methods change the status of the ball, depending on its status
	 * the player will score more or less points
	 * @see Round
	 */
	
	public void bonus() {
		status = Status.BONUS; 	
		log.info("ESTATUS DE BOLA CAMBIADO A: {}", status);
	}
	
	public void noPoint() {
		status = Status.NOPOINTS; 
		log.info("ESTATUS DE BOLA CAMBIADO A: {}", status);
	}
	
	public void standard() {
		status = Status.STANDARD;
		log.info("ESTATUS DE BOLA CAMBIADO A: {}", status);
	}
	
	public void out() {
		status = Status.OUT;
		log.info("ESTATUS DE BOLA CAMBIADO A: {}", status);
	}
	
}
