package nttdata.javat1.game;

import java.util.Arrays;
import java.lang.Object;

/**
 * <h2> Class ScoreTable - Contains the methods to store an array of bests Scores and the players who made it </h2>
 *   
 * @version 1.0
 * @author Santiago López Arredondo
 * @since 16-05-2022
 * @see Player
 */

public class ScoreTable {
	// Attributes//
	public Player[] players = new Player [5];	

	
	// Methods //
	/**
	 * Checks if the table contains a player with the same name and maxScore, uses the equals 
	 * method of the <b> Player </b> class
	 * @param pl1 Player that the method will search
	 * @return Returns true or false depending if the player is found or not.
	 * @see Player
	 */
	public boolean containsPlayer(Player pl1) {
		boolean contains = false;
		
		for (Player pl:players) {
			if (pl.equals(pl1)) {
				contains = true;
				break;
			}
			
		}
		
		return contains;
	}
	
	/**
	 * This method asks for a player, and, if any of the players in the array has less maxScore than the new player, it is replaced
	 * @param p - new Player to insert in the table
	 */
	public void replacePlayer(Player p) {
		Arrays.sort(players);
		
		for (int i =0; i<5; i++) {				
			if (players[i].maxScore<p.maxScore && !(containsPlayer(p))) {
				Object other = players[i];
				players[i] = p;
				
				p = (Player) other;
			}
		}
	}
	
	/**
	 * This method inserts a player into the table if it has at least a free index
	 * @param p - Player that we want to insert in the table
	 */
	
	public void insertPlayer(Player p) {
		for (int i = 0; i<5; i++) {
			if (players[i] == null) {
				players[i] = p;
				break;
			}
		}
	}
	
	/**
	 * This method orders and prints the array of the 5 best Scores, next to the player name who made it,
	 * it uses the <b> compareTo </b> method of the Player class to order the array
	 * @see Player
	 */
	
	public void showTable () {		
		Arrays.sort(players);
		String text;
						
		System.out.println("----------------------------");
		System.out.println("|TOP 5 MEJORES PUNTUACIONES|");
		System.out.println("----------------------------");
		
		for (int i = 0; i<5; i++) {
			int position = i+1;			
			text = players[i].toString();
			
						
			System.out.println("-PUESTO " + position + ":");
			System.out.println(text);
			System.out.println("--------------------------");		
		}
		
	}			
}
