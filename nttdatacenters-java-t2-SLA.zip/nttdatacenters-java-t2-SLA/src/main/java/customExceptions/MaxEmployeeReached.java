package customExceptions;

public class MaxEmployeeReached extends Exception {

	public String toString() {
		return "Error, ha alcanzado el número máximo de empleados";
	}
}
