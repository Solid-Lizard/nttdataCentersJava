package nttdata.javat2.bussiness;

/**
 * Enumerado - Position - Almacena las posibles posiciones que puede tener un empleado
 * 
 * @see Employee
 * 
 * @author Santiago
 */
public enum Position {
	LevelDesigner, Programmer, Director, Artist
}
