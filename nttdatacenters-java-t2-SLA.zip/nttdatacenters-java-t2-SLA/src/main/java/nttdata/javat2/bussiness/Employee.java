package nttdata.javat2.bussiness;

/**
 * Clase - Employee - Esta clase contiene los métodos y atributos necesarios para la correcta gestión
 * de la creación y consulta de datos de cada empleado
 * 
 * @see Position
 * 
 * @author Santiago
 */

public class Employee {
	
	//Attributes
	private final String companyName = "FromSoftware";
	private String name;
	
	private int id;	
	
	private Position position;
	
	// Builders //
	/**
	 * Constructor - Employee - Constructor vacío de empleado
	 */
	public Employee() {}
	
	/**
	 * Constructor - Employee - Constructor 2 de empleado
	 * 
	 * @param name - Nombre del empleado
	 * @param position - Posición del empleado
	 */
	public Employee (String name, Position position) {
		this.name = name;
		this.position = position;
	}
	
	// Get methods//
	
	/**
	 * Método - getId 
	 * 
	 * @return  integer - Id del empleado
	 */
	public int getId() {
		return this.id;
	}
	
	/**
	 * Método - getPosition
	 * 
	 * @return Position - Posición del empleado
	 */
	public Position getPosition() {
		return this.position;
	} 
	
	/**
	 * Método - getCompanyName
	 * 
	 * @return String - Nombre de la compañía a la que pertenece el empleado
	 */
	
	public String getCompanyName() {
		return this.companyName;
	}
	
	/**
	 * Método - getName
	 * 
	 * @return String - Nombre del empleado
	 */
	
	public String getName() {
		return this.name;
	}
	
	// Set methods //
	/**
	 * Método - setId - Establece el id del empleado
	 * 
	 * @param id - id del empleado
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * Método - setName - Establece el nombre del empleado
	 * 
	 * @param name - Nombre del empleado
	 */
	public void setName (String name) {
		this.name = name;
	}
	
	/**
	 * Método - setPosition - Establece la posición del empleado
	 * 	
	 * @param position - Posición del empleado
	 * @see Position
	 */
	public void setPosition (Position position) {
		this.position = position;
	}
	
	// toString & Equals //
	
	/**
	 * Método - toString - Muestra la información del empleado, esto incluye el nombre, posición, e ID
	 * <br>
	 * Sobreescribe el método toString de la clase <b> Object </b>
	 * @return String - Información del empleado
	 */
	@Override
	public String toString() {
		String res = "Nombre: " + this.name + "\n" + "Posición: " + this.position + "\n" + "ID: " + this.id + "\n" + "------------------------------";		
		return res;
	}
	
	/**
	 * Método - equals - Comprueba si dos empleados son iguales basándose en su nombre y en su Id
	 * 
	 * @param obj - Otro empleado con el que se va a comparar este empleado
	 * @return boolean - true si ambos tienen el mismo nombre o ID y false en caso contrario
	 */
	@Override
	public boolean equals (Object obj) {
		boolean res = false;
		
		Employee other = (Employee) obj;
		
		if (this.name.equalsIgnoreCase(other.name) || this.id == other.id) {
			res = true;
		}
		
		return res;
	}
	
}
