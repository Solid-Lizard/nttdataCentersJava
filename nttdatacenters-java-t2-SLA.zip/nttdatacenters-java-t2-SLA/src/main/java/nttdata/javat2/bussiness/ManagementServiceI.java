package nttdata.javat2.bussiness;

/**
 * Interfaz - ManagementServiceI - Contiene los métodos necesarios para la gestión correcta de los empleados en el sistema
 * <br>
 * Se encuentra implementada en la clase <b> ManagementServiceImpl </b>
 * 
 * @see ManagementServiceImpl
 * @see Employee
 * 
 * @author Santiago
 */

public interface ManagementServiceI {
	/**
	 * Método - register - Registra a un empleado en el sistema
	 * 
	 * @param employee - Empleado que se quiere registrar en el sistema
	 * @return boolean - true si el empleado se registra correctamente, false en caso contrario
	 * 
	 * @see Employee
	 */
	public boolean register(Employee employee);
	
	/**
	 * Método - eraseEmployee - versión 1 - Método que, dado un nombre, elimina al empleado que contenga ese mismo nombre del sistema 
	 * 
	 * @param name - Nombre del empleado
	 * @return boolean . true si se consigue eliminar correctamente al empleado, false en caso contrario
	 * 
	 * @see Employee
	 */
	public boolean eraseEmployee (String name);
	
	/**
	 * Método - eraseEmployee - versión 2 - Método que, dado un ID, elimina del sistema al empleado que contenga ese mismo ID
	 * 
	 * @param id - ID del empleado
	 * @return boolean - true si consigue eliminar correctamente al empleado, false en caso contrario
	 * 
	 * @see Employee
	 */	
	public boolean eraseEmployee (int id);
	
	/**
	 * Método - showEmployees - Muestra los datos de todos los empleados existentes gracias al método <b> toString </b> de la <b> clase Employee </b>
	 * 
	 * @see Employee	 
	 */	
	public void showEmployees();
	
	/**
	 * Método - showEmployees - Muestra el número de empleados existentes
	 * 
	 * @return Integer - Número de empleados existentes
	 */
	public int countEmployees();
	
	/**
	 * Método - searchEmploye - versión 1 - Busca y devuelve a un empleado dada su ID
	 * 
	 * @param id - ID del empleado buscado
	 * @return Employee - objeto de tipo "Employee" si lo encuentra, <b> null </b> en caso contrario
	 * 
	 * @see Employee
	 */	
	public Employee searchEmployee(int id);
	
	/**
	 * Método - searchEmploye - versión 2 - Busca y devuelve a un empleado dado su nombre
	 * 
	 * @param name - Nombre del empleado buscado
	 * @return Employee - objeto de tipo "Employee" si lo encuentra, <b> null </b> en caso contrario
	 * 
	 * @see Employee
	 */
	public Employee searchEmployee(String name);
		
}

