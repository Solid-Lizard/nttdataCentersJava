package nttdata.javat2.bussiness;

import java.util.HashMap;
import java.util.Map;

/**
 * Clase - ManagementServiceImpl - Implementación de la clase <b> ManagementServiceI </b>
 * 
 * @see ManagementServiceI
 * 
 * @author Solid Lizard
 */

public class ManagementServiceImpl implements ManagementServiceI {

	private int employeeId = 0;
	private static int employeeNums = 0;
	
	Map<Integer, Employee> employees = new HashMap<>();	
	
	public int [] notUsedID = new int[15];
	
	// Methods needed for managing maps and arrays
	
	/**
	 * Método - moveElements - Mueve todos los elementos de la tabla "notUsedID" a una posición un nivel anterior
	 * 	
	 */
	private void moveElements() {
		for (int i = 1; i<15; i++) {
			int element = notUsedID[i]; 
			int position = i -1; 
			
			notUsedID[position] = element;				
		}
		
		notUsedID[14] = 0;		
	}
	
	/**
	 * Método - recoverID - Almacena en la tabla "notUsedID" la id de un empleado
	 * 
	 * @param id - ID que se va a almacenar
	 */
	private void recoverID(int id) {
		
		for (int i = 0; i<15; i++) {
			
			if (notUsedID[i] == 0) {
				notUsedID[i] = id;
				break;
			}
		}
	}
	
	/**
	 * Método - insertNotUsedID - Método que recupera la primera posición de la tabla "notUsedID"
	 * 
	 * @return int - ID situada en la primera posición de la tabla
	 */
	private int insertNotUsedID() {
		int res = notUsedID[0];
		moveElements();
		return res;
	}
	
	/**
	 * Método - containsEmployee - Método que comprueba si un empleado se encuentra almacenado en el mapa
	 * 
	 * @return boolean - true si el empleado se encuentra en la tabla, false en caso contrario
	 * 
	 * @see Employee
	 */
	private boolean containsEmployee(Employee emp) {
		boolean res = false;
		
		for (Object obj : employees.keySet()) {
			if (employees.get(obj).equals(emp)) {
				res = true;
				break;
			}
		}
		
		return res;
	}
	
	// Erase & register employees //
	/**
	 * Método - eraseEmployee - Método que implementa el método de la interfaz  "ManagementServiceI"
	 * 
	 * @param name
	 * @return boolean
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public boolean eraseEmployee(String name) {
		int id = searchEmployee(name).getId();				
		
		return eraseEmployee(id);
	}

	/**
	 * Método - eraseEmployee - Método que implementa el método de la interfaz  "ManagementServiceI"
	 * 
	 * @param id
	 * @return boolean
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public boolean eraseEmployee(int id) {
		boolean res = false;
		
		Employee emp = employees.remove(id);
		
		if (emp != null) {
			employeeNums--;
			recoverID(emp.getId());
			res = true;			
		}
		
		return res;
	}
	
	/**
	 * Método - register - Método que implementa el método de la interfaz  "ManagementServiceI"
	 * 
	 * @param employee
	 * @return boolean
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public boolean register(Employee employee) {
		boolean res = false;
				
		if (employeeNums<15 && !(containsEmployee(employee)) )  {	
			
			if (notUsedID[0] != 0) {
				employee.setId(insertNotUsedID());		
				
			} else {			
				employeeId++;			
				
				employee.setId(employeeId);													
				
			}
			
			
			employees.put(employee.getId(), employee);	
			employeeNums++;
			
			res = true;	
				
			} 														
		
		return res;			
	}

	// Show & Count employees //
	
	/**
	 * Método - showEmployees - Método que implementa el método de la interfaz  "ManagementServiceI"
	 * 	
	 * @see ManagementServiceI
	 */
	@Override
	public void showEmployees() {
		for (Object emp: employees.keySet()) {
			System.out.println(employees.get(emp));
		}
				
		
	}

	/**
	 * Método - countEmployees - Método que implementa el método de la interfaz  "ManagementServiceI"
	 * 
	 * @return Integer
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public int countEmployees() {	
		return employeeNums;
	}	

	
	// Search employee //
	
	/**
	 * Método - searchEmployee - Método que implementa el método de la interfaz  "ManagementServiceI"
	 * 
	 * @param id
	 * @return Employee	 
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public Employee searchEmployee(int id) {
		Employee res = employees.get(id);	
		
		return res;
	}

	/**
	 * Método - searchEmployee - Método que implementa el método de la interfaz  "ManagementServiceI"
	 * 
	 * @param name
	 * @return Employee
	 * 
	 * @see ManagementServiceI
	 */
	@Override
	public Employee searchEmployee(String name) {
		Employee res = null;
		
		for (Object obj: employees.keySet()) {
			String otherName = employees.get(obj).getName();
			
			if (otherName.equals(name)) {
				res = employees.get(obj);
				break;
			}
			
		}
		
		return res;
	}	
	
	
}
