package nttdata.javat2;

import nttdata.javat2.bussiness.Employee;
import nttdata.javat2.bussiness.ManagementServiceImpl;
import nttdata.javat2.bussiness.Position;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Clase - TSMainSLA - Clase principal del proyecto
 * 
 * @author Santiago
 */

public class T2MainSLA {
	/**
	 * Método - main - Método principal del proyecto
	 * <br>
	 * Se encarga de gestionar los métodos de la clase "ManagementServiceImpl" para asegurar un corrrecto
	 * funcionamiento del programa
	 * 
	 * @see ManagementServiceImpl
	 * @param args
	 */
	public static void main (String[] args) {
		
		// Objects and variables //
		ManagementServiceImpl ms = new ManagementServiceImpl();
		
		Employee e1 = new Employee("Hidetaka Miyazaki", Position.Director);
		Employee e2 = new Employee("Hideo Kojima", Position.Director);
		Employee e3 = new Employee("Santiago", Position.Director);
		
		Scanner sc = new Scanner(System.in);
		
		// Instructions //		
		ms.register(e1);
		ms.register(e2);
		ms.register(e3);
				
		try {
			int option;
			
			do {
				System.out.println(" -----Bienvenido al servicio de gestión de empleados-----");
				System.out.println(" -¿Qué desea?: ");
				System.out.println(" 1.-Mostrar número de empleados");
				System.out.println(" 2.-Mostrar todos los empleados");
				System.out.println(" 3.-Buscar empleado");		
				System.out.println(" 4.-Registrar empleado");
				System.out.println(" 5.-Eliminar empleado");	
				System.out.println(" 6.- Salir");
				
				System.out.print(" Su opción: ");
				
				option = sc.nextInt();
				
				while (option >6 || option <1) {
					System.out.print(" Error, introduzca un número del 1 al 6: ");
					option = sc.nextInt();
				}
				
				switch (option) {
				case 1:
					System.out.println(" --------------------------------------------------------");
					System.out.print (" Numero de empleados: ");
					System.out.println(ms.countEmployees());
					System.out.println(" --------------------------------------------------------");			
									
					break;
					
				case 2:
					System.out.println(" --------------------------------------------------------");	
					ms.showEmployees();
					System.out.println(" --------------------------------------------------------");
					break;
					
				case 3:
					System.out.println(" ¿Desea buscarlo por nombre o por ID?");
					System.out.println(" 1.-Nombre");
					System.out.println(" 2.-ID");
					
					int opt = sc.nextInt();
					
					while (opt != 1 && opt !=2) {
						System.out.println(" Error, introduzca un número del 1 al 2");
						opt = sc.nextInt();
					}
					
					if (opt == 1) {
						System.out.println("Introduzca el nombre correctamente porfavor: ");
						sc.nextLine();
						String name = sc.nextLine();
						
						Employee emp = ms.searchEmployee(name);
						
						if (emp == null) {
							System.out.println(" Error, no existe ningún empleado con ese nombre");
							
						} else {
							System.out.println(" Empleado encontrado, mostrando información: ");
							System.out.println(emp);
						}
						
						
					} else {
						System.out.println(" Introduzca el ID porfavor: ");
						int ans = sc.nextInt();
						
						Employee emp = ms.searchEmployee(ans);
						
						if (emp == null) {
							System.out.println(" Error, no existe ningún empleado con ese ID");
							
						} else {
							System.out.println(" Empleado encontrado, mostrando información: ");
							System.out.println(emp);
						}
						
					}
					
					break;
				
				case 4:
					Employee emp = new Employee();
					
					System.out.println(" Introduzca los datos del empleado porfavor: ");
					System.out.print(" Nombre: ");
					
					sc.nextLine();					
					String name = sc.nextLine();									
					
					emp.setName(name);
					
					System.out.println("");
					
					System.out.println(" Posición: ");
					System.out.println(" 1.- Director");
					System.out.println(" 2.- Diseñador de niveles");
					System.out.println(" 3.- Artista");
					System.out.println(" 4.- Programador");
					
					option = sc.nextInt();
					
					while (option>4 || option<1) {
						System.out.println(" Error, has introduce un número del 1 al 4 porfavor");
						option = sc.nextInt();
					}
					
					Position pos;
					
					switch (option) {
						case 1:
							pos = Position.Director;
							break;
							
						case 2:
							pos = Position.LevelDesigner;
							break;
							
						case 3:
							pos = Position.Artist;
							break;
							
						default: 
							pos = Position.Programmer;
							break;
							
					}
					
					emp.setPosition(pos);
					
					if (ms.register(emp)) {
						System.out.println("Empleado creado satisfactoriamente, ID asignado: " + emp.getId());
						
					} else {
						System.out.println("Error al crear el empleado, compruebe que no existe otro empleado con el mismo nombre");
					}
					
					break;
					
				case 5:
					
					System.out.println("Indique si va a introducir el ID o el nombre del empleado:");
					System.out.println(" 1.-Nombre");
					System.out.println(" 2.-ID");
					
					opt = sc.nextInt();
					
					while (opt != 1 && opt !=2) {
						System.out.println(" Error, introduzca un número del 1 al 2");
						opt = sc.nextInt();
					}
					
					if (opt == 1) {
						System.out.println("Introduzca el nombre correctamente porfavor: ");
						sc.nextLine();
						name = sc.nextLine();
						
						if (ms.eraseEmployee(name)) {
							System.out.println("Empleado eliminado correctamente");
							
						} else {
							System.out.println("Ha ocurrido un error al eliminar al empleado, porfavor, introduzca correctamente el nombre o asegúrese de que el empleado existe");
						}						
						
					} else {
						System.out.println(" Introduzca el ID porfavor: ");
						int ans = sc.nextInt();
												
						
						if (ms.eraseEmployee(ans)) {
							System.out.println(" Empleado eliminado correctamente");
							
						} else {
							System.out.println(" Ha ocurrido un error al eliminar al empleado, porfavor, introduzca correctamente el nombre o asegúrese de que el empleado existe");							
						}						
					}
					
					break;
				
				default:
					System.out.println("¡Vuelve pronto!");
				}
				
			} while (option != 6);
			
		} catch(InputMismatchException ex) {
			System.out.println("Error, introduzca un valor válido, terminando programa...");
		}
		
	}
}
